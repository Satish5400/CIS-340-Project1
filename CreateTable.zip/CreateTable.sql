CREATE TABLE `project1`.`patient` (
  `PatientId` INT NOT NULL,
  `FirstName` VARCHAR(45) NOT NULL,
  `LastName` VARCHAR(45) NOT NULL,
  `Address` VARCHAR(45) NOT NULL,
  `PhoneNo` VARCHAR(45) NOT NULL,
  `DateOfBirth` DATE NOT NULL,
  `Sex` CHAR(5) NOT NULL,
  `MaritalStatus` CHAR(5) NOT NULL,
  `RegDate` DATE NOT NULL,

  PRIMARY KEY (`PatientId`));
  
  
  CREATE TABLE `project1`.`ward` (
  `WardNo` INT NOT NULL,
  `WardName` VARCHAR(45) NOT NULL,
  `WardLocation` VARCHAR(45) NOT NULL,
  `NoOfBed` INT NOT NULL,
  `PhoneExt` INT NOT NULL,
  PRIMARY KEY (`WardNo`));
  
  
CREATE TABLE `project1`.`staff` (
  `StaffId` INT NOT NULL,
  `FirstName` VARCHAR(45) NOT NULL,
  `LastName` VARCHAR(45) NOT NULL,
  `Address` VARCHAR(45) NOT NULL,
  `PhoneNo` VARCHAR(45) NOT NULL,
  `DateOfBirth` DATE NOT NULL,
  `sex` CHAR(5) NOT NULL,
  `StaffType` CHAR(4) NULL,
  `NationalInsuranceNumber` VARCHAR(45) NOT NULL,
  `Position` VARCHAR(45) NOT NULL,
  `Salary` FLOAT NULL,
  `SalaryScale` VARCHAR(45) NOT NULL,
  `InstitutionName` VARCHAR(45) NOT NULL,
  `OrgName` VARCHAR(45) NOT NULL,
  `PositionHeld` VARCHAR(45) NOT NULL,
  `StartDate` DATE NOT NULL,
  `EndDate` DATE NOT NULL,
  `NoOFHour` INT NULL,
  `ContractType` VARCHAR(45) NULL,
    `TypeOfSalary` CHAR(5) NOT NULL,
`Shift` CHAR(5) NOT NULL,
`DateOfQua` DATE NOT NULL,
`TypeOfQua`VARCHAR(40 ) NOT NULL,

  PRIMARY KEY (`StaffId`));
  
  CREATE TABLE `project1`.`patientkins` (
  `NextOfkin` VARCHAR(5) NOT NULL,
  `RelationShip` VARCHAR(45) NOT NULL,
  `KinAddress` VARCHAR(45) NOT NULL,
  `KinPhoneNo` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`NextOfkin`));
  CREATE TABLE `project1`.`localdoctor` (
  `DoctorName` VARCHAR(20) NOT NULL,
  `ClinicNo` VARCHAR(45) NOT NULL,
  `ClinicPhoneNo` VARCHAR(45) NOT NULL,
  `ClinicAddress` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`ClinicNo`));
  
  CREATE TABLE `project1`.`patients appointments` (
  `PatientID` INT NOT NULL,
  `AppointmentID` VARCHAR(45) NOT NULL,
  `DoctorId` VARCHAR(45) NOT NULL,
  `DateBooked` DATE NOT NULL,
  `RoomNumber` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`PatientID`));
  
  CREATE TABLE `project1`.`inpatients` (
  `PatientFirstName` INT NOT NULL,
  `PatientLastName` VARCHAR(45) NOT NULL,
  `WaitlistNo` VARCHAR(45) NOT NULL,
  `PatientBedNumber` VARCHAR(45) NOT NULL,
  `Patient_DOB` DATE NOT NULL,
  PRIMARY KEY (`PatientFirstName`));
  
  CREATE TABLE `project1`.`outpatients` (
  `PatientFirstName` INT NOT NULL,
  `PatientLastName` VARCHAR(45) NOT NULL,
  `PatientAddress` VARCHAR(45) NOT NULL,
  `Patient_Phone` VARCHAR(45) NOT NULL,
  `Patient_DOB` DATE NOT NULL,
  PRIMARY KEY (`PatientFirstName`));
  
  CREATE TABLE `project1`.`patient medications` (
  `PatientFirstName` INT NOT NULL,
  `PatientLastName` VARCHAR(45) NOT NULL,
  `PatientMedicationName` VARCHAR(45) NOT NULL,
  `PatientDOB` DATE NOT NULL,
  PRIMARY KEY (`PatientFirstName`));
  
  CREATE TABLE `project1`.`surgical and nonsurgicalsupplies` (
  `SurgItem` VARCHAR(30) NOT NULL,
  `NonSurgitems` VARCHAR(45) NOT NULL,
  `ItemId` INT NOT NULL,
  `Name` VARCHAR(45) NOT NULL,
  `Desc` VARCHAR(45) NOT NULL,
  `QuantityStock` INT NOT NULL,
  `ReOrder` INT NOT NULL,
  `COST` DECIMAL(8,4) NOT NULL,
  `SuppId` INT NOT NULL,
  PRIMARY KEY (`ItemId`));
  
  CREATE TABLE `project1`.`pharmaceutical supplies` (
  `DrugId` INT NOT NULL,
  `Name` VARCHAR(45) NOT NULL,
  `Desc` VARCHAR(45) NOT NULL,
  `Dosage` VARCHAR(45) NOT NULL,
  `Adminstration` VARCHAR(45) NOT NULL,
  `QuantityStock` INT NOT NULL,
  `Reorder` INT NOT NULL,
  `Cost` DECIMAL(8,2) NOT NULL,
  PRIMARY KEY (`DrugId`));
  CREATE TABLE `project1`.`suppliers` (
  `SupplierId` INT NOT NULL,
  `SupplierName` VARCHAR(45) NOT NULL,
  `Address` VARCHAR(45) NOT NULL,
  `Phone` VARCHAR(12) NOT NULL,
  `FaxNum` VARCHAR(45) NOT NULL,
  `SuppliesType` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`SupplierId`));
  
  CREATE TABLE `project1`.`ward req` (
  `ReqNum` INT NOT NULL,
  `ReqName` VARCHAR(45) NOT NULL,
  `WardName` VARCHAR(45) NOT NULL,
  `WardNum` VARCHAR(45) NOT NULL,
  `DrugId` INT NOT NULL,
  `DrugName` VARCHAR(45) NOT NULL,
  `DesDrug` VARCHAR(45) NOT NULL,
  `Dosage` VARCHAR(45) NOT NULL,
  `Adminstration` VARCHAR(45) NOT NULL,
  `Cost` DECIMAL(8,2) NOT NULL,
  `Quantity` INT NOT NULL,
  `Date` DATE NOT NULL,
  `ChargeNurse` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`ReqNum`));
  
  CREATE TABLE `project1`.`pharmaceuticalorder` (
  `PharmOrderID` INT NOT NULL,
  `DrugId` INT NOT NULL,
  `SuppId` INT NOT NULL,
  PRIMARY KEY (`PharmOrderID`));
  
  CREATE TABLE `project1`.`workshift` (
  `ShiftId` INT NOT NULL,
  `StaffId` INT NOT NULL,
  `WardNum` INT NOT NULL,
  PRIMARY KEY (`ShiftId`));
  
 